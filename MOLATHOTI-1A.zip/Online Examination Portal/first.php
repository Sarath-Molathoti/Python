 <?php
session_start();
//$_SESSION['duration'] = $_SESSION;
$_SESSION['start_time'] = date("Y-m-d H:i:s");
$end_time = date('Y-m-d H:i:s', strtotime('+'.$_SESSION['time'].'minutes',strtotime($_SESSION['start_time'])));
$_SESSION['end_time'] = $end_time;
//echo 'ALL THE BEST';
//header("Location:quiz.php");
//require 'quiz.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="refresh" content="1; quiz.php">
	<title>Good Luck</title>
	<style type="text/css">
		.msg{
			margin-left: 280px;
			margin-top: 200px;
			text-align: center;
			background-color: rgba(0,0,0,0.9);
			color: red;
			font-weight: bold;
			font-size: 80px;
			height: 130px;
			border-radius: 10px;
			width: 500px;
		}
	</style>
</head>
<body>

     <div class="msg">All The Best</div>
</body>
</html>
