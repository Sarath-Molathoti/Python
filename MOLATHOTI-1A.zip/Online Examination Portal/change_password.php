<?php
require 'db_connect.php';
$newPassword=$_POST['n_password'];
$email=$_POST['n_email'];
    $result=mysqli_query($con,"SELECT * FROM personal_info WHERE EMAIL='$email' ");
    $row=mysqli_num_rows($result);
    //echo $count;
      if($row){
		$rows = mysqli_query($con, "UPDATE personal_info SET PASSWORD='$newPassword' WHERE EMAIL='$email' ");
		$_COOKIE['pass']=$newPassword;
		echo "<script>
				var r=alert('Password changed Successfully');
 	 			window.location.href='login.php';
 		      </script>";
	}
	else{
		echo "<script>
				var r=alert('There is no such email.Invalid Email address');
 	 			window.location.href='forgot.php';
 		      </script>";
	}
?>