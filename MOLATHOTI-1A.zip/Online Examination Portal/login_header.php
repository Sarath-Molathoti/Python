<!DOCTYPE html>
<html>
<head>
	<title>Online Examination Portal</title>

<style type="text/css">
	html, body, {
    position:fixed;
    top:0;
    bottom:0;
    left:0;
    right:0;
	}
	a {
		text-decoration: none;
		margin-left: 30px;
		font-size: 20px;
		color: white;
		margin-top: 30px;
		margin-left: 1100px;
	}
	a:hover{
		text-decoration: none;
		background-color: #00ff00;
		padding: 10px;
	}
	.navigation_bar{
		padding-top: 22px;
		height: 50px;
		background-color: #800080;
	}
	
	
</style>
</head>
<body>
	<div class="navigation_bar">
		<a href="thanks.php">Logout</a>	
	</div>
</body>
</html>