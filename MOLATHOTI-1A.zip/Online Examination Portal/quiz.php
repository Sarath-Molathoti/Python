<?php
  //require 'login_header.php';
  require 'db_connect.php';
 
  session_start();
  $typeid=$_SESSION['typeid'];
  $email=$_SESSION['useremail'];
  $time=$_SESSION['time'];
  $rad_val=5;
 
  if(isset($_POST['next_btn']) || isset($_POST['sub_btn']) || isset($_POST['pre_btn'])){
  	$qid = $_SESSION['counter'];
  	if (isset($_POST['choice'])) {
  		$yourans = $_POST['choice'];
  		$check=mysqli_query($con,"SELECT * FROM user_answers WHERE TYPEID='$typeid' AND QID='$qid' AND EMAIL='$email' ");
  		$c=mysqli_num_rows($check);
  		if($c!=0){
  		    mysqli_query($con,"UPDATE user_answers SET USER_ANS='$yourans' WHERE TYPEID='$typeid' AND QID='$qid' AND EMAIL='$email' ");
  		}else{
  		mysqli_query($con,"INSERT INTO user_answers(TYPEID,QID,USER_ANS,EMAIL) VALUES ('$typeid','$qid','$yourans','$email')");
  	    }
  	 	//$_SESSION['attempted']++; 	 	
  	 	/* $result2=mysqli_query($con,"SELECT * FROM questions WHERE TYPEID='$typeid' AND QID='$qid' AND ANS='$yourans' ") or die("Could not execute query: " .mysqli_error($con));
  		 $count2=mysqli_num_rows($result2);
  		if($count2==1){
  		 	//$_SESSION['score']++;
  		}
  		else{
  			//$_SESSION['wrong']++;
  		 	$a = $_SESSION['wqid']++;
  		 	$wrong_qns=mysqli_query($con,"INSERT INTO wrong(TYPEID,WQID,QID) VALUES ('$typeid','$a','$qid') ");	 	
  		}
  	}
  	else{
  		$a = $_SESSION['wqid']++;
  		mysqli_query($con,"INSERT INTO wrong(TYPEID,WQID,QID) VALUES ('$typeid','$a','$qid') ");
  	 	//$_SESSION['not_attempted']++;
  	}*/
  }
  }

   /*if (isset($_POST['n_submit'])) {
  	  echo "<script>
				var r=alert('Your exam is Over');
 	 			window.location.href='result.php';
 		      </script>";
    }*/

  if(isset($_POST['next_btn'])){
    $_SESSION['counter']++;
  }elseif(isset($_POST['pre_btn'])){
    $_SESSION['counter']--;
  }elseif(isset($_POST['sub_btn'])){
  	  echo "<script>
				var r=alert('Your exam is Over');
 	 			window.location.href='quiz_eval.php';
 		      </script>";
  }

  $no = $_SESSION['counter'];
  $result1=mysqli_query($con,"SELECT * FROM questions WHERE TYPEID='$typeid' ") or die("Could not execute query: " .mysqli_error($con));
  $number_of_qns=mysqli_num_rows($result1);
  $_SESSION['total']=$number_of_qns;

  if ($time == "1 Minute") {
  	 $_SESSION['total'] = 2;
  	 $number_of_qns = 2;
  }elseif ($time == "3 Minutes") {
  	$_SESSION['total'] = 3;
  	$number_of_qns = 3;
  }elseif($time == "5 Minutes"){
  	$_SESSION['total'] = 5;
  	$number_of_qns = 5;
  }elseif($time == "10 Minutes"){
  	$_SESSION['total'] = 10;
  	$number_of_qns = 10;
  }
  


  $result=mysqli_query( $con, "SELECT * FROM questions WHERE QID='$no' AND TYPEID='$typeid' ") or die("Could not execute query: " .mysqli_error($con));
  $row=mysqli_fetch_assoc($result);

  $result2=mysqli_query($con,"SELECT * FROM user_answers WHERE QID='$no' AND TYPEID='$typeid' AND EMAIL='$email' ");
  $count=mysqli_num_rows($result2);
  if ($count!=0) {
  	$row2=mysqli_fetch_assoc($result2);
  	$rad_val=$row2['USER_ANS'];
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Quiz</title>
	<style type="text/css">

		body{
			margin: 0px;
			padding: 0px;
			background-color: lime;
		}
		.profile {
			background-color: deeppink;
			height: 597px;
			width: 340px;
			float: left;
			margin-top: 0px;
		}
		
		.tab1 {
			background-color: rgba(0,0,0,0.9);
			margin-left: 390px;
			border: 2px solid black;
			width: 800px;
			padding: 20px;
			margin-top: 20px;
			border-radius: 15px;

		}
		.t1{
			margin-top: 50px;
			margin-left: 950px;
			background-color: rgba(0,0,0,0.9);
			color: white;
			font-size: 24px;
			width: 200px;
			height: 100px;
			border-radius: 10px;
			padding: 15px;
			text-align: center;

		}
		button{
			height: 28px;
			width: 120px;
			border: 2px solid lavender;
		}
		button:hover{
			height: 30px;
			width: 125px;
		}
		.pre{
			width: 140px;
			height: 28px;
			background-color: yellow;
			margin-left: 350px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.pre:hover{
			width: 145px;
			height: 30px;
			background-color: yellow;
			margin-left: 350px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.pre2{
			width: 140px;
			height: 28px;
			background-color: yellow;
			margin-left: 500px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.pre2:hover{
			width: 145px;
			height: 30px;
			background-color: yellow;
			margin-left: 500px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.next{
			background-color: deeppink;
			margin-left: 10px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.next1{
			background-color: deeppink;
			margin-left: 500px;
			font-weight: bold;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.sub{
			background-color: aqua;
			font-weight: bold;
			margin-left: 10px;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.sub1{
			background-color: aqua;
			font-weight: bold;
			margin-left: 10px;
			font-family: sans-serif;
			border-radius: 3px;
		}
		.sub2{
			background-color: aqua;
			font-weight: bold;
			margin-left: 10px;
			font-family: sans-serif;
			border-radius: 3px;
		}
	    .c1{
	    	text-align: center;
			font-size: 22px;
			margin-top: 10px;
			font-weight: bold;
			font-family: serif;
			color: black;
			
		}
		.c2{
	    	text-align: center;
			font-size: 22px;
			margin-top: 10px;
			font-weight: bold;
			font-family: serif;
			color: black;
			
		}
		.c3{
	    	text-align: center;
			font-size: 22px;
			margin-top: 45px;
			font-weight: bold;
			font-family: serif;
			color: white;
			
		}
		.c4{
	    	text-align: center;
			font-size: 22px;
			margin-top: 10px;
			font-weight: bold;
			font-family: serif;
			color: white;
		}
		
		.c5{
	    	text-align: center;
			font-size: 22px;
			margin-top: 10px;
			font-weight: bold;
			font-family: serif;
			color: white;
		}
		#respo{
			font-size: 26px;
			margin-top: 5px;
		}
		.r1{
			text-align: center;
	
			margin-top: 0px;
			color: blue;
			font-weight: bold;
			font-size: 32px;
		}
		input[type="radio"]:checked{
			background-color: blue;
		}
		
	</style>
	
</head>
<body>
	
	
	
		
		<form  name="myform" action="quiz.php" method="POST">
		<div class="qns">
			
			<div class="profile">
			   
			    			<?php
			    		
    							//echo "yes";
    							$q1=mysqli_query($con,"SELECT * FROM personal_info WHERE EMAIL='$email' ");
    							$per=mysqli_fetch_array($q1);
    							$q2=mysqli_query($con,"SELECT * FROM educational_info WHERE EMAIL='$email' ");
    							$edu=mysqli_fetch_array($q2);
    							//echo $row['image'];
    							//echo "tes";
    							echo '<img src="data:image/jpeg;base64,'.base64_encode( $per['IMAGE'] ).'" height="140px" width="140px" style="border-radius:70px; margin-left:95px;margin-top:70px;" />';
  
    						?>
			    		
			    		        <div class="c1"><?php echo $per["NAME"]; ?></div>
			    		        <div class="c2"><?php echo $edu["EMAIL"]; ?></div>
			    				<div class="c3"><?php echo $edu["COLLEGE"]; ?></div>
			    				<div class="c4"><?php echo $edu["BRANCH"]; ?></div>
			    				<div class="c5"><?php echo $edu["YEAR"]; ?></div>
			    				
			</div>
			<div ><div class="r1">Online Examination</br><?php echo $_SESSION['subject']; ?></div>
			      
			      <div class="t1">Total Time : <?php echo ' '.$_SESSION['time'].' Min'; ?></br>Time Ends in <div id="respo"></div></div>
		    </div>
		<table class="tab1">
			<tr><td style="color: red;font-size: 20px;"><?php echo $row['QID'].'. '.$row['QUESTION']; ?></td></tr>
		   <div >
			<tr><td style="color: blue;font-size: 20px;"><input type='radio' name="choice" value="0" <?php if($rad_val==0){?> checked="checked" <?php } ?>>
				<?php echo $row['ANS1']; ?></td></tr>
			<tr><td style="color: blue;font-size: 20px;"><input type='radio' name="choice" value="1" <?php if($rad_val==1){?> checked="checked" <?php } ?>>
				<?php echo $row['ANS2']; ?></td></tr>
			<tr><td style="color: blue;font-size: 20px;"><input type='radio' name="choice" value="2" <?php if($rad_val==2){?> checked="checked" <?php } ?>>
				<?php echo $row['ANS3']; ?></td></tr>
			<tr><td style="color: blue;font-size: 20px;"><input type='radio' name="choice" value="3" <?php if($rad_val==3){?> checked="checked" <?php } ?>>
				<?php echo $row['ANS4']; ?></td></tr>
			</div>
			<?php 
			if($no==1){
			echo '<tr><td><button name="next_btn" class="next1">Next Question</button></td><td><button name="sub_btn" class="sub1">Submit</button></td></tr>';
			}
			?>
			<?php 
			if($no!=$number_of_qns && $no!=1){
			echo '<tr><td><button name="pre_btn" class="pre">Previous Question</button></td><td><button name="next_btn" class="next">Next Question</button></td>
			<td><button name="sub_btn" class="sub">Submit</button></td></tr>';
		    }
		    ?>
		    
			<?php 
			if($no==$number_of_qns){
			echo '<tr><td><button name="pre_btn" class="pre2">Previous Question</button></td><td><button name="sub_btn" class="sub2">Submit</button></td></tr>';
			
			}
			?>
		</table>
		</div>
	</form>
	
	
</body>


<script type="text/javascript">
//setTimeout('xx()',60000);
 var x=setInterval(function(){
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.open("GET","response.php",false);
		xmlhttp.send(null);
		var str = document.getElementById("respo").innerHTML=xmlhttp.responseText;
		if(str.slice(6,8) == "00" && str.slice(3,5) == "00"){
			alert("Time Up");
			window.location.href='quiz_eval.php';
		}
	},1000);
	//function xx(){
			//clearInterval(x);
			//alert("Time Up");
			//window.location.href='quiz_eval.php';
			//clearInterval(y);
	//}

</script>

</html>