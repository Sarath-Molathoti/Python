<!DOCTYPE html>
<html>
<head>
	<title>Select Category</title>
	<style type="text/css">
	    body{
	margin: 0px;
	padding: 0px;
	background-color: rgba(255,255,0,1);
}
     
     select{
     	outline: none;
		width: 270px;
		height: 35px;
		background-color: aqua;
		font-size: 15px;
		color: black;
		margin-bottom: 15px;
		font-family: sans-serif;
		margin-left: 10px;
		border-radius: 5px;

	}
	input[type='submit']{
		outline: none;
		border: none;
		width: 270px;
		height: 35px;
		background-color: red;
		font-size: 18px;
		color: white;
		margin-top: 20px;
		border-radius: 9px;
		font-family: sans-serif;
		font-weight: bold;
	
	}
	input[type="submit"]:hover{
		background-color: purple;
		color: white;
	}
	   
	</style>
</head>
<body>
	<center>
		<h1 style="margin-bottom: 50px;margin-top: 60px; color: indigo;">Please Select Your Interest</h1>
		<form action="instructions.php" method="POST">
		      <b style="font-size: 22px;color: ;">Select Subject</b> <select name="n_category" required="true" placeholder="">
				          <option value="HTML">Html</option>
				          <option value="CSS">Css</option>
				          <option value="JAVASCRIPT">JavaScript</option>
				          <option value="PHP">Php</option>
				</select></br>
				<b style="font-size: 22px;color: ;">Choose Time</b> <select name="n_time" required="true" placeholder="" style="margin-left: 17px;">
				          <option value="1 Minute">1 Minute</option>
				          <option value="3 Minutes">3 Minutes</option>
				          <option value="5 Minutes">5 Minutes</option>
				          <option value="10 Minutes">10 Minutes</option>
				</select></br>
				<input type="submit" name="opt" value="Submit">

	    </form>
	</center>
</body>
</html>