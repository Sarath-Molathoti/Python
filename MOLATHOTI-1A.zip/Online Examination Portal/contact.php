<?php 
 require 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<style type="text/css">
		body{
    	margin: 0px;
    	padding: 0px;
    	background-color: orangered;

    }
    .inf{
    	margin-top: 200px;
    	color: white;
    	font-weight: bold;
    	font-size: 24px;
    	font-family: serif;
    }
    pre{
    	background-color: rgba(0,0,0,0.9);
    	padding: 20px;
    	width: 80%;
    	margin: auto;
    	border-radius: 20px;
    }
	</style>
</head>
<body >
	
		<div class="inf">
			<pre>
  If you have any further questions, please don’t hesitate to contact me
       Please feel free to call me on (8639428419) or contact by 
  (sarathmolathoti@gmail.com), if you require any further information
		          </pre>
	</div>

</body>
</html>