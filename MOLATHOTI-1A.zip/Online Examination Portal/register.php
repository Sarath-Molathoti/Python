<?php
require 'db_connect.php';
$p_name=$_POST["n_name"];
$p_rollno=$_POST["n_rollno"];
$p_email=$_POST["n_email"];
$p_password=$_POST["n_password"];
$p_gender=$_POST["n_gender"];
$p_dob=$_POST["n_dob"];
$p_college=$_POST["n_college"];
$p_branch=$_POST["n_branch"];
$p_year=$_POST["n_year"];
$p_mobile=$_POST["n_mobile"];
$count=0;
$useremail=mysqli_query($con,"SELECT EMAIL FROM personal_info WHERE EMAIL='$p_email'") or die("can't");
$count=mysqli_num_rows($useremail);
if($count!=0){
	echo "<script>
				var r=alert('User with this email already exists.Please try with different email id');
 	 			window.location.href='signup.php';
 		      </script>";
}else{
 $image1= addslashes(file_get_contents($_FILES['image']['tmp_name']));

$result1=mysqli_query($con,"INSERT INTO personal_info(NAME,EMAIL,PASSWORD,DOB,GENDER,MOBILE,IMAGE) VALUES('$p_name','$p_email','$p_password',
         '$p_dob','$p_gender','$p_mobile','$image1')");
$result2=mysqli_query($con,"INSERT INTO educational_info(EMAIL,COLLEGE,BRANCH,YEAR) VALUES ('$p_email','$p_college','$p_branch','$p_year')");
echo "<script>
				var r=alert('Registered Successfully');
 	 			window.location.href='login.php';
 		      </script>";
}
 



?>
