<?php 
 require 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<style type="text/css">
		body{
    	margin: 0px;
    	padding: 0px;
    	background-color: orangered;

    }
    .inf{
    	margin-top: 200px;
    	color: white;
    	font-weight: bold;
    	font-size: 24px;
    	font-family: serif;
    }
    pre{
    	background-color: rgba(0,0,0,0.9);
    	padding: 20px;
    	width: 80%;
    	margin: auto;
    	border-radius: 20px;
    }
	</style>
</head>
<body >
	
		<div class="inf">
			<pre>
 Online examination is conducting a test online to measure the knowledge 
 of the participants on a given topic. In the olden days everybody had to 
   gather in a classroom at the same time to take an exam. With online 
 examination students can do the exam online, in their own time and with 
		their own device,regardless where they live.
		          </pre>
	</div>

</body>
</html>