<?php
 session_start();
 $username = $_SESSION['username'];
 $_SESSION['counter'] = 1;
 $_SESSION['score'] = 0;
 $_SESSION['wrong'] = 0;
 $_SESSION['wqid'] = 0;
 $_SESSION['attempted'] = 0;
 $_SESSION['wrong_or_unanswered'] = 0;
 $_SESSION['not_attempted'] = -1;
 $_SESSION['subject'] = $_POST['n_category'];
 if(isset($_POST['opt'])){
 if ($_POST['n_category'] == "HTML") {
 	$_SESSION['typeid']=1;
 }elseif ($_POST['n_category'] == "CSS") {
 	$_SESSION['typeid']=2;
 }elseif ($_POST['n_category'] == "JAVASCRIPT") {
 	$_SESSION['typeid']=3;
 }elseif ($_POST['n_category'] == "PHP") {
 	$_SESSION['typeid']=4;
 }

 if ($_POST['n_time'] == "1 Minute") {
 	$_SESSION['time'] = 1;
 }elseif ($_POST['n_time'] == "3 Minutes") {
 	$_SESSION['time'] = 3;
 }elseif ($_POST['n_time'] == "5 Minutes") {
 	$_SESSION['time'] = 5;
 }elseif ($_POST['n_time'] == "10 Minutes") {
 	$_SESSION['time'] = 10;
 }
}
 ?>
 

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Instructions</title>
 	<style type="text/css">
 		body{
 			margin: 0px;
 			padding: 0px;
 		}
 		.instr{
 			background-color: Lavender;
 			margin-left: 200px;
 			width: 70%;
 			font-size:20px;
 			color: black;
 			padding: 20px;
 			margin-top: 10px;
 		}
 		
 		.start{
 			border: 2px solid pink;
 			background-color: red;
 			color: white;
 			padding: 10px;
 			font-weight: bold;
 			border-radius: 8px;
 			margin: 40px;
 			margin-left: 400px;
 		    margin-top: 50px;
 			text-decoration: none;

 		}
 		a:hover{
 			background-color: aqua;
 			font-weight: bold;
 			color: black;
 		}
 	</style>
 </head>
 <body>
 	<div class="instr">

 		<h3>Hii...<div style="color: green"><?php echo $username ?></div></h3>
 		<h1>Instructions for the Your Exam</h1>
 		
 		<p>
 			1. In the rare and unlikely event of a technical failure during the test, the candidate may be required
			to attempt the test again.</br>

			2. The candidates must ensure that the computer allotted to them is switched on and any problem
			with the computer should be informed to the invigilator immediately.</br>

			3. Details like your Name, Roll No, Form no etc are to be filled on the space provided on the space
			provided on the screen for test appearance.</br>

			4. There is no time limit for individual parts of the test. The candidate can go back and change any
			of his/her answers among the 10 questions.</br>

			5. All questions will be of the Multiple Choice Question (MCQ type). Each MCQ will consist of a
			stem which may be in the form of a question or an incomplete statement and four options.</br>
			6. Candidates must choose the correct or most appropriate answer by clicking on the button next to
			the answer. Candidates can navigate freely through the questions.</br>
			7. At the conclusion of the test you should follow the instruction of the invigilator in order to properly
			record/save your test work.</br>
			8. Blank sheets for rough work will be provided, if required.</br>

 		</p>
 		<a href="first.php" class="start"><b>Start Quiz</b></a>
 	</div>
 	
 
 </body>
 </html>