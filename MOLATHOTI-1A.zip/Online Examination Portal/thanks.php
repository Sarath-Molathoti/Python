<?php 
session_destroy();
 require 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Thanks Giving</title>
	<style type="text/css">
		body{
    	margin: 0px;
    	padding: 0px;
    	background-color: orangered;

    }
    .inf{
    	background-color: rgba(0,0,0,0.9);
    	padding: 20px;
    	width: 50%;
    	margin: auto;
    	border-radius: 20px;
        margin-top: 200px;
        color: white;
        font-weight: bold;
        font-size: 34px;
        font-family: serif;
        text-align: center;
    }
	</style>
</head>
<body >
	
		<div class="inf">
			Thank you for the Exam
	</div>

</body>
</html>